var searchData=
[
  ['estapartidafinalizada',['estaPartidaFinalizada',['../classActividad4.html#a646ea569d68870fe882316f81f57662b',1,'Actividad4']]]
];
