var searchData=
[
  ['pasarsiguientejugador',['pasarSiguienteJugador',['../classActividad4.html#a23cf00e913eac32dea7597b617728047',1,'Actividad4']]]
];
