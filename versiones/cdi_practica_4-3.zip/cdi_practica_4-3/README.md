# Actividad 4

Grupo CDI_4

> Victor Málvarez Filgueira
> Martín Molina Álvarez

## Respuestas

### 1
-

### 2
-

### 3
-

